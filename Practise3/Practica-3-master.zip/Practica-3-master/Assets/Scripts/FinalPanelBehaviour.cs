﻿using UnityEngine;
using UnityEngine.UI;

public class FinalPanelBehaviour : MonoBehaviour
{
	// Clase que representa el panel de fin de juego
	// TODO
}
